using TallyAgent.Core.Configuration;

namespace TallyAgent.Core.Tally.Extractors;

public enum DatasetKind
{
    Master,       // full re-extract each cycle (cheap collections)
    Voucher,      // date-windowed via Day Book fan-out
    Snapshot,     // date-ranged report snapshot (TB, BS, P&L, stock summary, outstanding)
}

public sealed record DatasetDefinition(string Name, DatasetKind Kind, string BigQueryTable);

/// <summary>The 33 datasets from Tally_Schema_Design.xlsx, with enable-flag filtering.</summary>
public static class DatasetRegistry
{
    public static readonly IReadOnlyList<DatasetDefinition> All =
    [
        // Masters
        new("companies",              DatasetKind.Master,   "tally_companies"),
        new("groups",                 DatasetKind.Master,   "tally_groups"),
        new("ledgers",                DatasetKind.Master,   "tally_ledgers"),
        new("voucher_types",          DatasetKind.Master,   "tally_voucher_types"),
        new("cost_centres",           DatasetKind.Master,   "tally_cost_centres"),
        new("cost_categories",        DatasetKind.Master,   "tally_cost_categories"),
        new("currencies",             DatasetKind.Master,   "tally_currencies"),
        new("uom",                    DatasetKind.Master,   "tally_uom"),
        new("gst_rates",              DatasetKind.Master,   "tally_gst_rates"),
        // Inventory masters
        new("stock_groups",           DatasetKind.Master,   "tally_stock_groups"),
        new("stock_items",            DatasetKind.Master,   "tally_stock_items"),
        new("godowns",                DatasetKind.Master,   "tally_godowns"),
        new("stock_standard_costs",   DatasetKind.Master,   "tally_stock_standard_costs"),
        new("stock_standard_prices",  DatasetKind.Master,   "tally_stock_standard_prices"),
        // Voucher-derived (Day Book fan-out)
        new("vouchers",               DatasetKind.Voucher,  "tally_vouchers"),
        new("voucher_headers",        DatasetKind.Voucher,  "tally_voucher_headers"),
        new("voucher_lines",          DatasetKind.Voucher,  "tally_voucher_lines"),
        new("bill_allocations",       DatasetKind.Voucher,  "tally_bill_allocations"),
        new("bank_allocations",       DatasetKind.Voucher,  "tally_bank_allocations"),
        new("cost_centre_allocations",DatasetKind.Voucher,  "tally_cost_centre_allocations"),
        new("inventory_entries",      DatasetKind.Voucher,  "tally_inventory_entries"),
        new("day_book",               DatasetKind.Voucher,  "tally_day_book"),
        new("bank_book",              DatasetKind.Voucher,  "tally_bank_book"),
        new("sales_register",         DatasetKind.Voucher,  "tally_sales_register"),
        new("purchase_register",      DatasetKind.Voucher,  "tally_purchase_register"),
        new("sales_invoice_lines",    DatasetKind.Voucher,  "tally_sales_invoice_lines"),
        new("voucher_guid_manifest",  DatasetKind.Voucher,  "tally_voucher_guid_manifest"),
        // Snapshot reports
        new("trial_balance",          DatasetKind.Snapshot, "tally_trial_balance"),
        new("balance_sheet",          DatasetKind.Snapshot, "tally_balance_sheet"),
        new("profit_loss",            DatasetKind.Snapshot, "tally_profit_loss"),
        new("stock_summary",          DatasetKind.Snapshot, "tally_stock_summary"),
        new("outstanding_payables",   DatasetKind.Snapshot, "tally_outstanding_payables"),
        new("outstanding_receivables",DatasetKind.Snapshot, "tally_outstanding_receivables"),
    ];

    private static readonly HashSet<string> InventoryDatasets =
        ["stock_groups","stock_items","godowns","stock_standard_costs","stock_standard_prices",
         "inventory_entries","stock_summary"];

    private static readonly HashSet<string> GstDatasets =
        ["gst_rates","sales_register","purchase_register","sales_invoice_lines"];

    private static readonly HashSet<string> CostCentreDatasets =
        ["cost_centres","cost_categories","cost_centre_allocations"];

    /// <summary>Reports known to make Tally compute across the whole company.
    /// On 2026-09-02 a cycle with snapshots enabled reached balance_sheet and
    /// hung tally.exe until it was force-closed; the datasets after it in run
    /// order (including both outstandings) were never attempted. Recommended
    /// off — derive them in BigQuery from ledgers/groups, vouchers and
    /// stock_items/inventory_entries instead.</summary>
    public static readonly IReadOnlySet<string> HeavyReports =
        new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            { "balance_sheet", "profit_loss", "stock_summary" };

    /// <summary>Datasets where zero rows is a suspicious result rather than a
    /// legitimately empty table. Every Snapshot already qualifies by kind; this
    /// set adds the Masters for which silence would hide a real problem.
    ///
    /// EMPTY since v2.3.0. It existed for opening_bills, which is now retired
    /// (see below) rather than left checkpointing on nothing.</summary>
    public static readonly IReadOnlySet<string> ExpectedNonEmptyMasters =
        new HashSet<string>(StringComparer.OrdinalIgnoreCase);

    /// <summary>
    /// RETIRED in v2.3.0: opening_bills.
    ///
    /// It produced zero rows for its entire history. The cause was diagnosed as
    /// the FETCH list asking for "BILLALLOCATIONS.LIST" — a serialisation name,
    /// not a fetchable member, which Tally ignores silently — but the fix was
    /// never confirmed against a live Tally, and shipping an unverified fix for
    /// a dataset that has never produced a row is how it stayed broken for
    /// months in the first place.
    ///
    /// It is removed rather than left in place because a registered dataset that
    /// checkpoints successfully on nothing is worse than no dataset at all: it
    /// reports health it does not have. Nothing is lost — it has never carried a
    /// single row — and the outstanding bill detail it was meant to provide is
    /// now covered by bills_payable / bills_receivable.
    ///
    /// MasterExtractor.OpeningBills and `TallyAgent.Cli diagnose-opening-bills`
    /// are both still present, so it can be revived the moment there is evidence
    /// that the request returns data.
    /// </summary>
    public const string RetiredOpeningBills = "opening_bills";

    /// <summary>
    /// RETIRED in v2.3.0: bills_payable, bills_receivable.
    ///
    /// They asked Tally to COMPUTE something the agent already has the inputs
    /// for. bill_allocations carries, per allocation row: bill_ref, bill_type
    /// (New Ref / Agst Ref / Advance / On Account), amount, ledger_name (the
    /// party — allocations hang off the party's ledger entry), voucher_guid,
    /// voucher_date and voucher_type. Matching New Ref and Advance against
    /// Agst Ref by bill_ref within a party reproduces both reports in SQL, which
    /// is the approach tally-database-loader takes; it never requests a Bills
    /// Payable report either. 7,559 allocation rows were flowing on the day this
    /// was decided.
    ///
    /// So the report route was pure cost: a heavy computation on Tally's single
    /// application thread, an envelope shape that took three attempts to pin
    /// down, and a parser that could only ever be as right as the guess behind
    /// it. Deriving downstream is cheaper, verifiable in SQL, and cannot hang
    /// tally.exe.
    ///
    /// ReportExtractor.Bills and ParseBillsReport remain — `TallyAgent.Cli
    /// verify` still parses a Tally bills export with them, which is how the
    /// derivation gets checked against Tally's own numbers.
    /// </summary>
    public static readonly IReadOnlySet<string> RetiredBillsReports =
        new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            { "bills_payable", "bills_receivable" };

    /// <summary>Should a zero-row result from this dataset be reported rather
    /// than checkpointed as a success?</summary>
    public static bool ExpectsRows(DatasetDefinition d) =>
        d.Kind == DatasetKind.Snapshot || ExpectedNonEmptyMasters.Contains(d.Name);

    /// <summary>Datasets enabled by the config toggles.</summary>
    public static IReadOnlyList<DatasetDefinition> Enabled(TallySettings s) =>
        All.Where(d => IsEnabled(d, s)).ToList();

    private static bool IsEnabled(DatasetDefinition d, TallySettings s)
    {
        if (!s.EnableInventory && InventoryDatasets.Contains(d.Name)) return false;
        if (!s.EnableGst && GstDatasets.Contains(d.Name)) return false;
        if (!s.EnableCostCentres && CostCentreDatasets.Contains(d.Name)) return false;
        return d.Kind switch
        {
            DatasetKind.Master => s.EnableMasters,
            DatasetKind.Voucher => s.EnableVouchers,
            DatasetKind.Snapshot => s.IsSnapshotEnabled(d.Name),
            _ => true,
        };
    }
}
